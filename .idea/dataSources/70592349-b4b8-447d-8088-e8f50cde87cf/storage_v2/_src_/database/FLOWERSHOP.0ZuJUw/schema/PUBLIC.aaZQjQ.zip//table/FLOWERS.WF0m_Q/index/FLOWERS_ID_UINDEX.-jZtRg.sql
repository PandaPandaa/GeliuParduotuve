create unique index FLOWERS_ID_UINDEX
    on FLOWERS (ID);

