create unique index ORDERS_ID_UINDEX
    on ORDERS (ID);

